
var show_box = function show_box(id) {
	$('.widget-box.visible').removeClass('visible');
	$('#' + id).addClass('visible');
};

$(function() {


	$.post('/users/session',{userName:'kebin',password:'kebin',provider:'local'},function(data,status){
			console.info(status);
		});

	// $.post('/users', {
	// 	email: '2@2.com',
	// 	userName: 2,
	// 	password: 2,
	// 	provider: 'local'
	// }, function(data, status) {
	// 	console.info(status);
	// });


});