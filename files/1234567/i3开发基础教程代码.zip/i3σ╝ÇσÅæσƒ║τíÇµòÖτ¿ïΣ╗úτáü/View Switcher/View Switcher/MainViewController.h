//
//  MainViewController.h
//  View Switcher
//
//  Created by Pepper's mpro on 5/3/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import "FlipsideViewController.h"

@interface MainViewController : UIViewController <FlipsideViewControllerDelegate>

@end
