//
//  AppDelegate.h
//  View Switcher
//
//  Created by Pepper's mpro on 5/3/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
