//
//  ViewController.m
//  Button Fun
//
//  Created by Pepper's mpro on 3/27/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController
@synthesize statusText;

-(IBAction)buttonPressed:(id)sender
{
    NSString *title=[sender titleForState:UIControlStateNormal];
    NSString *newText=[[NSString alloc]initWithFormat:@"%@ button pressed.",title];
    statusText.Text=newText;
    [newText release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

-(void)viewDidUnload
{
    self.statusText=nil;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc
{
    [statusText release];
    [super dealloc];
}

@end
