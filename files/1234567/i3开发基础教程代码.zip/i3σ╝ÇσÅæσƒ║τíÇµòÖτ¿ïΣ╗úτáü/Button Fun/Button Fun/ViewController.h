//
//  ViewController.h
//  Button Fun
//
//  Created by Pepper's mpro on 3/27/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    UILabel *statusText;
}
@property (nonatomic,retain) IBOutlet UILabel *statusText;
- (IBAction)buttonPressed:(id)sender;
@end
