//
//  AppDelegate.h
//  Button Fun
//
//  Created by Pepper's mpro on 3/27/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    UIWindow *window;
    ViewController *viewController;
}

@property (strong, nonatomic) IBOutlet UIWindow *window;
@property (nonatomic,retain) IBOutlet ViewController *viewController;

@end
