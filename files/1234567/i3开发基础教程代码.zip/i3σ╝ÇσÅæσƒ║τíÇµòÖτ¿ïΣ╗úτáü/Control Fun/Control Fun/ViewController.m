//
//  ViewController.m
//  Control Fun
//
//  Created by Pepper's mpro on 3/29/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import "ViewController.h"


@implementation ViewController
@synthesize nameField;
@synthesize numberField;
@synthesize sliderLabel;
@synthesize leftSwitch;
@synthesize rightSwitch;
@synthesize doSomethingButton;

-(IBAction)textFieldDoneEditing:(id)sender
{
    [sender resignFirstResponder];
}

-(IBAction)backgroundTap:(id)sender
{
    [nameField resignFirstResponder];
    [numberField resignFirstResponder];
}

-(IBAction)sliderChanged:(id)sender
{
    UISlider *slider = (UISlider *)sender;
    int progressAsInt=(int)(slider.value+0.5f);
    NSString *newText=[[NSString alloc] initWithFormat:@"%d",progressAsInt];
    sliderLabel.text = newText;
    [newText release];
}

-(IBAction) toggleControls:(id)sender
{
    if([sender selectedSegmentIndex]==kSwitchesSegmentIndex)
    {
        leftSwitch.hidden = NO;
        rightSwitch.hidden = NO;
        doSomethingButton.hidden = YES;
    }
    else
    {
        leftSwitch.hidden = YES;
        rightSwitch.hidden = YES;
        doSomethingButton.hidden = NO;

    }
}

-(IBAction)switchChanged:(id)sender
{
    UISwitch *whichSwitch = (UISwitch *)sender;
    BOOL setting = whichSwitch.isOn;
    [leftSwitch setOn:setting animated:YES];
    [rightSwitch setOn:setting animated:YES];
}

-(IBAction)buttonPressed
{
    //TODO:Implement Action Sheet and Alert
    UIActionSheet *actionSheet=[[UIActionSheet alloc]
                                initWithTitle:@"Are you sure?"
                                     delegate:self
                            cancelButtonTitle:@"No way!"
                       destructiveButtonTitle:@"Yes,I'm sure"
                            otherButtonTitles:nil];
    [actionSheet showInView:self.view];
    [actionSheet release];
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex != [actionSheet cancelButtonIndex])
    {
        NSString *msg;
        if(nameField.text.length>0)
            msg = [[NSString alloc]initWithFormat:
                   @"You can breath easy,%@,everything went OK.",
                   nameField.text];
        else
            msg = @"You can breath easy,everything went OK";
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"something ws done"
                              message:msg
                              delegate:self
                              cancelButtonTitle:@"phew!"
                              otherButtonTitles:nil];
        [alert show];
        [alert release];
        [msg release];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidUnload
{
    self.nameField=nil;
    self.numberField=nil;
    self.sliderLabel=nil;
    self.leftSwitch=nil;
    self.rightSwitch=nil;
    self.doSomethingButton=nil;
    [super viewDidUnload];
}

-(void)dealloc
{
    [nameField release];
    [numberField release];
    [sliderLabel release];
    [leftSwitch release];
    [rightSwitch release];
    [doSomethingButton release];
    [super dealloc];
}

@end
