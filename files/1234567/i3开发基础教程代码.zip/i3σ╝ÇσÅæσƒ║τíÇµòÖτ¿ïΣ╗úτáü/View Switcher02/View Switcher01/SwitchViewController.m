//
//  SwitchViewController.m
//  View Switcher01
//
//  Created by Pepper's mpro on 5/3/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import "SwitchViewController.h"
#import "BlueViewController.h"
#import "YellowViewController.h"

@interface SwitchViewController ()

@end

@implementation SwitchViewController
@synthesize yellowViewController;
@synthesize blueViewController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    BlueViewController *blueController = [[BlueViewController alloc]
                                          initWithNibName:@"BlueViewController" bundle:nil];
    self.blueViewController = blueController;
    [self.view insertSubview:blueController.view atIndex:0];
    [blueController release];
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}
-(IBAction)switchViews:(id)sender
{
    /////
    [UIView beginAnimations:@"View Flip" context:nil];
    [UIView setAnimationDuration:1.25];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    /////
    if(self.yellowViewController.view.superview == nil)
    {
        if(self.yellowViewController == nil)
        {
            YellowViewController *yellowController = [[YellowViewController alloc]initWithNibName:@"YellowViewController"bundle:nil];
            self.yellowViewController = yellowController;
            [yellowController release];
        }
        //--
        [UIView setAnimationTransition:
         UIViewAnimationTransitionFlipFromRight forView:self.view cache : YES];
        [blueViewController viewWillAppear:YES];
        [yellowViewController viewWillDisappear:YES];
        //--
        [blueViewController.view removeFromSuperview];
        [self.view insertSubview:yellowViewController.view atIndex:0];
        
        //---
        [yellowViewController viewDidDisappear:YES];
        [blueViewController viewDidAppear:YES];
        //---
        
    }
    else
    {
        if(self.blueViewController == nil)
        {
            BlueViewController *blueController = [[BlueViewController alloc]initWithNibName:@"BlueViewController"bundle:nil];
            self.blueViewController = blueController;
            [blueController release];
        }
        //--
        [UIView setAnimationTransition:
         UIViewAnimationTransitionFlipFromLeft forView:self.view cache : YES];
        [yellowViewController viewWillAppear:YES];
        [blueViewController viewWillDisappear:YES];
        //--
        [yellowViewController.view removeFromSuperview];
        [self.view insertSubview:blueViewController.view atIndex:0];
        
        //---
        [blueViewController viewDidDisappear:YES];
        [yellowViewController viewDidAppear:YES];
        //---
    }
    [UIView commitAnimations];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    if(self.blueViewController.view.superview == nil)
        self.blueViewController = nil;
    else
        self.yellowViewController = nil;
}
-(void)dealloc
{
    [yellowViewController release];
    [blueViewController release];
    [super dealloc];
}

@end
