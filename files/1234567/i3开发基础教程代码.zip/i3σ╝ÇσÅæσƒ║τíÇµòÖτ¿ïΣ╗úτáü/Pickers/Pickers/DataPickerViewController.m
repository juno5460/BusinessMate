//
//  DataPickerViewController.m
//  Pickers
//
//  Created by Pepper's mpro on 5/7/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import "DataPickerViewController.h"

@interface DataPickerViewController ()

@end

@implementation DataPickerViewController
@synthesize datePicker;

-(IBAction)buttonPressed
{
    NSDate *selected=[datePicker date];
    NSString *message = [[NSString alloc]initWithFormat:
                         @"The date and time you selected is: %@",selected];
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@"Date and time Selected"
                                message:message
                               delegate:nil
                      cancelButtonTitle:@"Yes,I did."
                      otherButtonTitles:nil];
    [alert show];
    [alert release];
    [message release];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    NSDate *now=[[NSDate alloc]init];
    [datePicker setDate:now animated:NO];
    [now release];
//    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    self.datePicker = nil;
    [super viewDidUnload];
}

-(void)dealloc
{
    [datePicker release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
