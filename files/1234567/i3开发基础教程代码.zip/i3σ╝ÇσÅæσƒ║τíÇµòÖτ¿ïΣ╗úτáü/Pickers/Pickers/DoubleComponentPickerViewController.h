//
//  DoubleComponentPickerViewController.h
//  Pickers
//
//  Created by Pepper's mpro on 5/7/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import <UIKit/UIKit.h>
#define kFillingComponent 0
#define kBreadComponent 1

@interface DoubleComponentPickerViewController : UIViewController
     <UIPickerViewDelegate,UIPickerViewDataSource>
{
    UIPickerView *doublePicker;
    NSArray *fillingTypes;
    NSArray *breadTypes;
}
@property (nonatomic,retain)IBOutlet UIPickerView *doublePicker;
@property (nonatomic,retain)IBOutlet NSArray *fillingTypes;
@property (nonatomic,retain)IBOutlet NSArray *breadTypes;

-(IBAction)buttonPressed;

@end
