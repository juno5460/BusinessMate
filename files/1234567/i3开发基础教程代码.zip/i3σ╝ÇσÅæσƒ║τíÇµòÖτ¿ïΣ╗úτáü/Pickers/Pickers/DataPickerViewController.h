//
//  DataPickerViewController.h
//  Pickers
//
//  Created by Pepper's mpro on 5/7/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DataPickerViewController : UIViewController
{
    UIDatePicker *datePicker;
}
@property (nonatomic,retain)IBOutlet UIDatePicker *datePicker;
-(IBAction)buttonPressed;

@end
