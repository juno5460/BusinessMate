//
//  AppDelegate.h
//  Pickers
//
//  Created by Pepper's mpro on 5/7/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import <UIKit/UIKit.h>
@class DataPickerViewController;
@class SingleComponentPickerViewController;
@class DoubleComponentPickerViewController;
@class DependentComponentPickerViewController;
@class CustomPickerViewController;
@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    UIWindow *window;
//    DataPickerViewController *rootController;
    
    CustomPickerViewController *rootController;
    
}

@property (nonatomic,retain) IBOutlet UIWindow *window;
//@property (nonatomic,retain) IBOutlet DataPickerViewController *rootController;
@property (nonatomic,retain) IBOutlet CustomPickerViewController *rootController;
@end
