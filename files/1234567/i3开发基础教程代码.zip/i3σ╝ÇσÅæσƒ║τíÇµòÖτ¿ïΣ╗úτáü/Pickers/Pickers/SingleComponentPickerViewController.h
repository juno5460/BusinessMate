//
//  SingleComponentPickerViewController.h
//  Pickers
//
//  Created by Pepper's mpro on 5/7/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SingleComponentPickerViewController : UIViewController
     <UIPickerViewDelegate,UIPickerViewDataSource>
{
    UIPickerView *singlePicker;
    NSArray      *pickerData;
}
@property (nonatomic,retain) IBOutlet UIPickerView *singlePicker;
@property (nonatomic,retain) NSArray *pickerData;
-(IBAction)buttonPressed;

@end
