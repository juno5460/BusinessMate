//
//  SecondLevelViewController.h
//  Nav
//
//  Created by Pepper's mpro on 5/15/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SecondLevelViewController :UITableViewController
{
    UIImage *rowImage;
}
@property (nonatomic,retain) UIImage *rowImage;

@end
