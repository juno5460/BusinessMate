//
//  ViewController.m
//  Nav
//
//  Created by Pepper's mpro on 5/15/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)settingBtnAction:(id)sender {
    SettingViewController *view = [[SettingViewController alloc] initWithNibName:@"SettingViewController" bundle:Nil];
    [self.navigationController pushViewController:view animated:YES];
    
    [view release];
}
@end
