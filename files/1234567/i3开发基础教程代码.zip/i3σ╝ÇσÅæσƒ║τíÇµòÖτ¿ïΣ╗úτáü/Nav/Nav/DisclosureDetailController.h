//
//  DisclosureDetailController.h
//  Nav
//
//  Created by Pepper's mpro on 5/15/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DisclosureDetailController : UIViewController
{
    UILabel *label;
    NSString *message;
}
@property (nonatomic,retain)IBOutlet UILabel *label;
@property (nonatomic,retain)NSString *message;

@end