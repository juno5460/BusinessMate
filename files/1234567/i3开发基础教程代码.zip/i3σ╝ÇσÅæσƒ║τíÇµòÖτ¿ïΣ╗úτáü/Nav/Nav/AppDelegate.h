//
//  AppDelegate.h
//  Nav
//
//  Created by Pepper's mpro on 5/15/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    UIWindow *window;
    UINavigationController *navController;
}

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic,retain)  UINavigationController *navController;

@end
