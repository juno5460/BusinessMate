//
//  ViewController.h
//  Nav
//
//  Created by Pepper's mpro on 5/15/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SettingViewController.h"

@interface ViewController : UIViewController
- (IBAction)settingBtnAction:(id)sender;

@end
