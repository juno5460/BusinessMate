//
//  FirstLevelViewController.h
//  Nav
//
//  Created by Pepper's mpro on 5/15/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DisclosureButtonController.h"

@interface FirstLevelViewController : UITableViewController
{
    NSArray *controllers;
}
@property (nonatomic,retain)NSArray *controllers;

@end
