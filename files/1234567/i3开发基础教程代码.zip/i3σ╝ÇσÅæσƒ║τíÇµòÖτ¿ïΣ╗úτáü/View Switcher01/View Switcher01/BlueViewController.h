//
//  BlueViewController.h
//  View Switcher01
//
//  Created by Pepper's mpro on 5/7/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BlueViewController : UIViewController
{
    
}
-(IBAction)blueButtonPressed;

@end
