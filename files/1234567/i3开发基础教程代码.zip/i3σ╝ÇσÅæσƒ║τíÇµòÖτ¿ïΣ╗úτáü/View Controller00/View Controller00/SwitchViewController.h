//
//  SwitchViewController.h
//  View Controller00
//
//  Created by Pepper's mpro on 5/3/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>


@class BlueViewController;
@class YellowViewController;
@interface SwitchViewController : UIViewController
{
    YellowViewController *yellowViewController;
    BlueViewController *blueViewController;
}
@property (retain,nonatomic) YellowViewController *yellowViewController;
@property (retain,nonatomic) BlueViewController *blueViewController;

-(IBAction) switchViews : (id)sender;

@end
