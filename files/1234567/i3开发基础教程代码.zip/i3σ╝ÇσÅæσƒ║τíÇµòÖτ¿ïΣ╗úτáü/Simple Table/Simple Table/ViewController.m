//
//  ViewController.m
//  Simple Table
//
//  Created by Pepper's mpro on 5/10/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize listData;

- (void)viewDidLoad
{
    NSArray *array = [[NSArray alloc]initWithObjects:@"sleepy",@"Sneezy",@"Bashful",@"Happy",@"Doc",@"Grumpy",@"Dopey",@"Thorin",@"Dorin",@"Nori",@"Ori",@"Balin",@"Dwalin",@"Fili",@"Kili",@"Oin",@"Gloin",@"Bifur",@"Bombur", nil];
    self.listData=array;
    [array release];
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}
-(void)viewDidUnload
{
    self.listData = nil;
    [super viewDidUnload];
}
-(void)dealloc
{
    [listData release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -
#pragma mark Table View Data Source Methods
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.listData count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *SimpleTableIdentifier = @"SimpleTableIdentifier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:SimpleTableIdentifier];
    if(cell == nil)
    {
        cell=[[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:SimpleTableIdentifier]autorelease];
    }
    NSUInteger row = [indexPath row];
    cell.textLabel.text = [listData objectAtIndex:row];
    if(row < 3)
    {
    UIImage *image = [UIImage imageNamed:@"apple.png"];
    cell.imageView.image = image;
    }
    else if(row < 7)
    {
        UIImage *image = [UIImage imageNamed:@"lemon.png"];
        cell.imageView.image = image;
    }
    else if(row < 10)
    {
        UIImage *image = [UIImage imageNamed:@"cherry.png"];
        cell.imageView.image = image;
    }
    else if(row < 14)
    {
        UIImage *image = [UIImage imageNamed:@"seven.png"];
        cell.imageView.image = image;
    }
    else 
    {
        UIImage *image = [UIImage imageNamed:@"crown.png"];
        cell.imageView.image = image;
    }

    if(row < 7)
        cell.detailTextLabel.text = @"Mr.Disney";
    else
        cell.detailTextLabel.text = @"Mr.Tolkein";
    return cell;
}

-(void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSUInteger row = [indexPath row];
    NSString *rowValue = [listData objectAtIndex:row];
    
    NSString *message = [[NSString alloc]initWithFormat:@"You select %@",rowValue];
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Row Selected!" message:message delegate:nil cancelButtonTitle:@"Yes,I Did" otherButtonTitles: nil];
    [alert show];
    [message release];
    [alert release];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

@end
