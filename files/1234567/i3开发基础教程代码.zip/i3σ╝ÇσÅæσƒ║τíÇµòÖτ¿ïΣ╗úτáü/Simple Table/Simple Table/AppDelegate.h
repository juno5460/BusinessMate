//
//  AppDelegate.h
//  Simple Table
//
//  Created by Pepper's mpro on 5/10/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic,retain) UIWindow *window;

@property (nonatomic,retain) ViewController *viewController;

@end
