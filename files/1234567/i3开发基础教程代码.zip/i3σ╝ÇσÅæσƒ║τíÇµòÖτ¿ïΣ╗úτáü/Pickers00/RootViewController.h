//
//  RootViewController.h
//  Pickers
//
//  Created by Pepper's mpro on 5/9/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DataPickerViewController;
@class DoubleComponentPickerViewController;
@class SingleComponentPickerViewController;
@class DependentComponentPickerViewController;
@class CustomPickerViewController;
@interface RootViewController : UIViewController
{
    DataPickerViewController *dataPickerViewController;
    DoubleComponentPickerViewController *doubleComponentPickerViewController;
    SingleComponentPickerViewController *singleComponentPickerViewController;
    DependentComponentPickerViewController *dependentComponentPickerViewController;
    CustomPickerViewController *customPickerViewController;
}
@property (retain,nonatomic) DataPickerViewController *dataPickerViewController;
@property (retain,nonatomic) DoubleComponentPickerViewController *doubleComponentPickerViewController;
@property (retain,nonatomic) SingleComponentPickerViewController *singleComponentPickerViewController;
@property (retain,nonatomic) DependentComponentPickerViewController *dependentComponentPickerViewController;
@property (retain,nonatomic) CustomPickerViewController *customPickerViewController;

-(IBAction)dataPressed;
-(IBAction)singlePressed;
-(IBAction)doublePressed;
-(IBAction)dependentPressed;
-(IBAction)customPressed;
@end
