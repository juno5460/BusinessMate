//
//  AppDelegate.h
//  Pickers
//
//  Created by Pepper's mpro on 5/7/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import <UIKit/UIKit.h>
@class RootViewController;
@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    UIWindow *window;
    RootViewController *rootController;
    
}

@property (nonatomic,retain) IBOutlet UIWindow *window;
@property (nonatomic,retain) IBOutlet RootViewController *rootController;
@end
