//
//  RootViewController.m
//  Pickers
//
//  Created by Pepper's mpro on 5/9/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import "RootViewController.h"
#import "DataPickerViewController.h"
#import "SingleComponentPickerViewController.h"
#import "DoubleComponentPickerViewController.h"
#import "DependentComponentPickerViewController.h"
#import "CustomPickerViewController.h"
#import "AppDelegate.h"


@interface RootViewController ()

@end

@implementation RootViewController
@synthesize dataPickerViewController;
@synthesize singleComponentPickerViewController;
@synthesize doubleComponentPickerViewController;
@synthesize dependentComponentPickerViewController;
@synthesize  customPickerViewController;

-(IBAction)dataPressed
{
    if(self.dataPickerViewController.view.superview == nil)
    {
        if(self.dataPickerViewController == nil)
        {
            DataPickerViewController *dataController=[[DataPickerViewController alloc]initWithNibName:@"DataPickerViewController" bundle:nil];
            self.dataPickerViewController=dataController;
            [dataController release];
        }
        [singleComponentPickerViewController.view removeFromSuperview];
        [doubleComponentPickerViewController.view removeFromSuperview];
        [dependentComponentPickerViewController.view removeFromSuperview];
        [customPickerViewController.view removeFromSuperview];
        [self.view insertSubview:dataPickerViewController.view atIndex:0];
    }
}
-(IBAction)singlePressed
{
    if(self.singleComponentPickerViewController.view.superview == nil)
    {
        if(self.singleComponentPickerViewController==nil)
        {
             SingleComponentPickerViewController *singleController=[[SingleComponentPickerViewController alloc]initWithNibName:@"SingleComponentPickerViewController" bundle:nil];
            self.singleComponentPickerViewController=singleController;
            [singleController release];
        }
        [dataPickerViewController.view removeFromSuperview];
        [doubleComponentPickerViewController.view removeFromSuperview];
        [dependentComponentPickerViewController.view removeFromSuperview];
        [customPickerViewController.view removeFromSuperview];
        [self.view insertSubview:singleComponentPickerViewController.view atIndex:0];
    }
}
-(IBAction)doublePressed
{
    if(self.doubleComponentPickerViewController.view.superview==nil)
    {
        if(self.doubleComponentPickerViewController==nil)
        {
             DoubleComponentPickerViewController *doubleController=[[DoubleComponentPickerViewController alloc]initWithNibName:@"DoubleComponentPickerViewController" bundle:nil];
             self.doubleComponentPickerViewController=doubleController;
             [doubleController release];
        }
        [dataPickerViewController.view removeFromSuperview];
        [singleComponentPickerViewController.view removeFromSuperview];
        [dependentComponentPickerViewController.view removeFromSuperview];
        [customPickerViewController.view removeFromSuperview];
        [self.view insertSubview:doubleComponentPickerViewController.view atIndex:0];
    }
}
-(IBAction)dependentPressed
{
    if(self.dependentComponentPickerViewController.view.superview==nil)
    {
        if(self.dependentComponentPickerViewController==nil)
        {
             DependentComponentPickerViewController *dependentController=[[DependentComponentPickerViewController alloc]initWithNibName:@"DependentComponentPickerViewController" bundle:nil];
             self.dependentComponentPickerViewController=dependentController;
             [dependentController release];
        }
        [dataPickerViewController.view removeFromSuperview];
        [singleComponentPickerViewController.view removeFromSuperview];
        [doubleComponentPickerViewController.view removeFromSuperview];
        [customPickerViewController.view removeFromSuperview];
        [self.view insertSubview:dependentComponentPickerViewController.view atIndex:0];
    }
}
-(IBAction)customPressed
{
    if(self.customPickerViewController.view.superview==nil)
    {
        if(self.customPickerViewController==nil)
        {
             CustomPickerViewController *customController=[[CustomPickerViewController alloc]initWithNibName:@"CustomPickerViewController" bundle:nil];
             self.customPickerViewController=customController;
             [customController release];
        }
        [dataPickerViewController.view removeFromSuperview];
        [singleComponentPickerViewController.view removeFromSuperview];
        [doubleComponentPickerViewController.view removeFromSuperview];
        [dependentComponentPickerViewController.view removeFromSuperview];
        [self.view insertSubview:customPickerViewController.view atIndex:0];
    }
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewDidUnload
{
    [dataPickerViewController release];
    [singleComponentPickerViewController release];
    [doubleComponentPickerViewController release];
    [dependentComponentPickerViewController release];
    [customPickerViewController release];
    [super viewDidUnload];
}
-(void)dealloc
{
    self.dataPickerViewController=nil;
    self.doubleComponentPickerViewController=nil;
    self.dependentComponentPickerViewController=nil;
    self.singleComponentPickerViewController=nil;
    self.customPickerViewController=nil;
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
