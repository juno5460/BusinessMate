//
//  ViewController.m
//  Autosize
//
//  Created by Pepper's mpro on 3/29/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import "ViewController.h"


@implementation ViewController
@synthesize button1;
@synthesize button2;
@synthesize button3;
@synthesize button4;
@synthesize button5;
@synthesize button6;


-(void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    if(toInterfaceOrientation==UIInterfaceOrientationPortrait||toInterfaceOrientation==UIInterfaceOrientationPortraitUpsideDown)
    {
        button1.frame=CGRectMake(20,20,125,125);
        button2.frame=CGRectMake(175,20,125,125);
        button3.frame=CGRectMake(20,168,125,125);
        button4.frame=CGRectMake(175,168,125,125);
        button5.frame=CGRectMake(20,315,125,125);
        button6.frame=CGRectMake(175,315,125,125);
    }
    else
    {
        button1.frame=CGRectMake(20,20,125,125);
        button2.frame=CGRectMake(20,155,125,125);
        button3.frame=CGRectMake(177,20,125,125);
        button4.frame=CGRectMake(177,155,125,125);
        button5.frame=CGRectMake(328,20,125,125);
        button6.frame=CGRectMake(328,155,125,125);
    }
}

-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
{
    return (toInterfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidUnload
{
    self.button1=nil;
    self.button2=nil;
    self.button3=nil;
    self.button4=nil;
    self.button5=nil;
    self.button6=nil;
    [super viewDidUnload];
}

-(void)dealloc
{
    [button1 release];
    [button2 release];
    [button3 release];
    [button4 release];
    [button5 release];
    [button6 release];
    [super dealloc];
}

@end
