//
//  ViewController.h
//  Autosize
//
//  Created by Pepper's mpro on 3/29/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    UIButton *button1;
    UIButton *button2;
    UIButton *button3;
    UIButton *button4;
    UIButton *button5;
    UIButton *button6;
}
@property (nonatomic,retain)IBOutlet UIButton *button1;
@property (nonatomic,retain)IBOutlet UIButton *button2;
@property (nonatomic,retain)IBOutlet UIButton *button3;
@property (nonatomic,retain)IBOutlet UIButton *button4;
@property (nonatomic,retain)IBOutlet UIButton *button5;
@property (nonatomic,retain)IBOutlet UIButton *button6;

@end
