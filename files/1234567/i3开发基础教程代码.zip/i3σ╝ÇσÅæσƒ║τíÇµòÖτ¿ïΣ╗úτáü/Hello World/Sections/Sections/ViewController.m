//
//  ViewController.m
//  Sections
//
//  Created by Pepper's mpro on 5/13/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import "ViewController.h"
#import "NSDdictionary-MutableDeepCopy.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize names;
@synthesize keys;
@synthesize table;
@synthesize search;
@synthesize allNames;

#pragma mark -
#pragma mark Custom Methods
-(void)resetSearch
{//取消搜索或更改搜索条件时将调用此方法.
//    NSMutableDictionary *allNamesCopy = [self.allNames mutableDeepCopy];
//    self.names = allNamesCopy;
    self.names = [self.allNames mutableDeepCopy];
//    [allNamesCopy release];
    NSMutableArray *keyArray = [[NSMutableArray alloc]init];
    [keyArray addObjectsFromArray:[[self.allNames allKeys]sortedArrayUsingSelector:@selector(compare:)]];
    self.keys=keyArray;
    [keyArray release];
}

-(void)handleSearchForTerm:(NSString *)searchTerm
{//实现实际的搜索功能
    NSMutableArray *sectionsToRemove = [[NSMutableArray alloc]init]; //该数组存放空分区,后面用来删除
    [self resetSearch];  //重置搜索
    
    for(NSString *key in self.keys)   //枚举数组中所有键,每次循环获取对应于当前键的名称数组
    {
        NSMutableArray *array = [names valueForKey:key]; //如以'A'开头的所有名称串
        NSMutableArray *toRemove = [[NSMutableArray alloc]init];
        for(NSString *name in array)
        {
            if([name rangeOfString:searchTerm options:NSCaseInsensitiveSearch].location == NSNotFound)
                [toRemove addObject:name];
        }
        if([array count] == [toRemove count])
            [sectionsToRemove addObject:key];   
        
        [array removeObjectsInArray:toRemove];
        [toRemove release];
    }
    [self.keys removeObjectsInArray:sectionsToRemove];
    [sectionsToRemove release];
    [table reloadData];
}
- (void)viewDidLoad
{
    NSString *path = [[NSBundle mainBundle]pathForResource:@"sortednames" ofType:@"plist"];
    NSDictionary *dict = [[NSDictionary alloc]initWithContentsOfFile:path];
    self.allNames=dict;
    [dict release];
    [self resetSearch];
    [table reloadData];
    [table setContentOffset:CGPointMake(0.0,44.0) animated:NO];
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}
-(void)viewDidUnload
{
    self.table=nil;
    self.search = nil;
    self.allNames=nil;
    self.names=nil;
    self.keys=nil;
    [super viewDidUnload];
}

-(void)dealloc
{
    [table release];
    [search release];
    [allNames release];
    [names release];
    [keys release];
    [super dealloc];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark -
#pragma mark Table View Data Source Methods
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return ([keys count] > 0) ? [keys count] : 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if([keys count]==0)
        return 0;
    NSString *key=[keys objectAtIndex:section];
    NSArray *nameSection = [names objectForKey:key];
    return [nameSection count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSUInteger section = [indexPath section];
    NSUInteger row = [indexPath row];
    NSString *key = [keys objectAtIndex:section];
    NSArray *nameSection = [names objectForKey:key];
    static NSString *SectionsTableIdentifier = @"SectionsTableIdentifier";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:SectionsTableIdentifier];
    if(cell == nil)
    {
        cell=[[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SectionsTableIdentifier]autorelease];
    }
    cell.textLabel.text=[nameSection objectAtIndex:row];
    return cell;
}
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if([keys count]==0)
        return nil;
    NSString *key = [keys objectAtIndex:section];
    return key;
}
-(NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
    return keys;
}
#pragma mark -
#pragma mark Table View Delegate Methods
-(NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [search resignFirstResponder];
    return indexPath;
}
#pragma mark -
#pragma mark Search Bar Delegate Methods
-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    NSString *searchTerm = [searchBar text];
    [self handleSearchForTerm:searchTerm];
}
-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchTerm
{//实现现场搜索
    if([searchTerm length]==0)
    {
        [self resetSearch];
        [table reloadData];
        return;
    }
    [self handleSearchForTerm:searchTerm];
}
-(void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    search.text = @"";
    [self resetSearch];
    [table reloadData];
    [searchBar resignFirstResponder];
}
@end
