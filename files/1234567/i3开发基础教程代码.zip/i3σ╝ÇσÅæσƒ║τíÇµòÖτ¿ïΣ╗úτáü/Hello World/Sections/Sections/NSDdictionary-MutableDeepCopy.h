//
//  NSDdictionary-MutableDeepCopy.h
//  Sections
//
//  Created by Pepper's mpro on 5/13/13.
//  Copyright (c) 2013 foreveross. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary(MutableDeepCopy)
-(NSMutableDictionary *)mutableDeepCopy;
@end
